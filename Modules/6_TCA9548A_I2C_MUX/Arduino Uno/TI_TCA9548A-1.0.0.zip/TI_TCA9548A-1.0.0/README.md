# Arduino library for Texas Instruments (TI) TCA9548A Low-Voltage 8-Channel I²C Switch with Reset #

This is an Arduino-compatible library for the [Texas Instruments (TI) TCA9548A Low-Voltage 8-Channel I²C Switch with Reset](http://www.ti.com/lit/ds/symlink/tca9548a.pdf).
